# wix-velo-examples

This repo serves as a way to document some of the ways I used Velo in a WiX template to customize the experiences of users on a WiX site. These are examples and will probably need to be adapted to fit specific needs. I hoped to document this for myself so I can use as a resources for client website on WiX.

The backend folder is for code that would be placed in the WiX site backend area. You would need to enable dev mode in the WiX editor to see an option for the backend.

The other folders are based on the elements used to solve various problems.

P.S. I am using the file type `.js` because of local editing. However, files will need to be in `.jsw` format for WiX to use it. Its just WiX's version of a JavaScript file but they are pretty much the same thing.
